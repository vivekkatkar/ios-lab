 //
//  ViewController.swift
//  TravelPlanerApp
//
//  Created by Apple Lab 12 on 16/04/25.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Authenticate(_ sender: UIButton) {
        let username = Username.text ?? ""
        let password
        if(password == "pass" && username == "user"){
            
        }
    }
    
}

